﻿using System;
using System.IO;

namespace scoreboardApp
{
    class MainClass
    {
        static void Main(string[] args)
        {
            int team1Score = 0;
            int team1Set = 0;
            string name1 = "Home";

            int team2Score = 0;
            int team2Set = 0;
            string name2 = "Away";

            //Authenitcation screen
            Console.WriteLine("Enter your Username: ");
            string user = Console.ReadLine();
            Console.WriteLine("Enter your Password: ");
            string password = Console.ReadLine();
            if (user != "admin" || password != "password1")
            {
                Console.WriteLine("Incorrect username or password. Program session ending...");
                return;
            }

            ScoreboardScreen scoreboardScreen = new ScoreboardScreen(0, 0);
            PopUp popUp = new PopUp(4, 39);

            //Reads the save file and assigns each line to the variable
            using (System.IO.StreamReader file = new System.IO.StreamReader("nameScoreSaveFile.txt"))
            {
                name1 = file.ReadLine();
                team1Score = Convert.ToInt32(file.ReadLine());
                team1Set = Convert.ToInt32(file.ReadLine());
                name2 = file.ReadLine();
                team2Score = Convert.ToInt32(file.ReadLine());
                team2Set = Convert.ToInt32(file.ReadLine());
            }

                bool run = true;
                while (run)
                {

                    Console.Clear();
                    scoreboardScreen.Draw();

                    //set positions and colour for the team scores
                    Console.SetCursorPosition(9, 5);
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.Write(team1Score);
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.SetCursorPosition(36, 5);
                    Console.Write(team2Score);
                    //sets position and colour for the team sets
                    Console.SetCursorPosition(18, 7);
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.Write(team1Set);
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.SetCursorPosition(27, 7);
                    Console.Write(team2Set);
                    //sets position and colour for the team names
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.SetCursorPosition(7, 2);
                    Console.Write(name1);
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.SetCursorPosition(34, 2);
                    Console.Write(name2);
                    Console.ResetColor();
                    Console.SetCursorPosition(1, 19);

                    //Key presses
                    ConsoleKeyInfo keyPressed = Console.ReadKey(true);

                    if (keyPressed.Key.Equals(ConsoleKey.W))
                    {
                        team1Score++;
                    }
                    if (keyPressed.Key.Equals(ConsoleKey.S))
                    {
                        team1Score--;
                    }
                    if (keyPressed.Key.Equals(ConsoleKey.D))
                    {
                        team1Set++;
                    }
                    if (keyPressed.Key.Equals(ConsoleKey.A))
                    {
                        team1Set--;
                    }
                    if (keyPressed.Key.Equals(ConsoleKey.I))
                    {
                        team2Score++;
                    }
                    if (keyPressed.Key.Equals(ConsoleKey.K))
                    {
                        team2Score--;
                    }
                    if (keyPressed.Key.Equals(ConsoleKey.L))
                    {
                        team2Set++;
                    }
                    if (keyPressed.Key.Equals(ConsoleKey.J))
                    {
                        team2Set--;
                    }
                    //name change for team1
                    if (keyPressed.Key.Equals(ConsoleKey.E))
                    {
                        //Console.Clear();
                        Console.SetCursorPosition(7, 7);
                        popUp.Draw1();
                        Console.SetCursorPosition(9, 9);
                        name1 = Console.ReadLine();
                    Console.ResetColor();

                }
                    //name change for team2
                    if (keyPressed.Key.Equals(ConsoleKey.O))
                    {
                        //Console.Clear();
                        Console.SetCursorPosition(7, 7);
                        popUp.Draw2();
                        Console.SetCursorPosition(9, 9);
                        name2 = Console.ReadLine();
                    Console.ResetColor();
                }
                    //Reset team names and scores
                    if (keyPressed.Key.Equals(ConsoleKey.R))
                    {
                        //Console.Clear();
                        Console.SetCursorPosition(7, 7);
                        popUp.DrawReset();
                        Console.SetCursorPosition(9, 9);
                        string inputR = Console.ReadLine();
                        if (inputR == "y")
                        {
                            team1Score = 0;
                            team1Set = 0;
                            name1 = "Home";

                            team2Score = 0;
                            team2Set = 0;
                            name2 = "Away";
                        }
                        Console.ResetColor();
                }
                    //Exit the program
                    if (keyPressed.Key.Equals(ConsoleKey.Escape))
                    {
                        //Console.Clear();
                        Console.SetCursorPosition(7, 7);
                        popUp.DrawExit();
                        Console.SetCursorPosition(9, 9);
                        string inputE = Console.ReadLine();
                        if (inputE == "y")
                        {

                            run = false;
                        }
                    }
                }
                //Writes names and scores to a text file
                using (System.IO.StreamWriter ConnectionToTextFile = new System.IO.StreamWriter("nameScoreSaveFile.txt"))
                {
                    ConnectionToTextFile.WriteLine("{0}", name1);
                    ConnectionToTextFile.WriteLine("{0}", team1Score);
                    ConnectionToTextFile.WriteLine("{0}", team1Set);
                    ConnectionToTextFile.WriteLine("{0}", name2);
                    ConnectionToTextFile.WriteLine("{0}", team2Score);
                    ConnectionToTextFile.WriteLine("{0}", team2Set);
                }

            }
        }
    }

