﻿using System;
namespace scoreboardApp
{
    public class PopUp
    {
        //Character and line position
        private int xcoord; 
        private int ycoord;

        public PopUp (int x, int y)
        {
            xcoord = x;
            ycoord = y;
        }

        //Writes banner for team 1 onto the screen
        public void Draw1()
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("╔------Change Team 1 Name------╗");
            Console.WriteLine("       |Team 1 Name:                  |");
            Console.WriteLine("       |                              |");
            Console.WriteLine("       ╚--------Press [ENTER]---------╝");

        }
        //Writes banner for team 2 onto the screen
        public void Draw2()
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("╔------Change Team 2 Name------╗");
            Console.WriteLine("       |Team 2 Name:                  |");
            Console.WriteLine("       |                              |");
            Console.WriteLine("       ╚--------Press [ENTER]---------╝");

        }
        public void DrawReset()
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("╔---------Reset Scores---------╗");
            Console.WriteLine("       |Are you sure [y/n]?           |");
            Console.WriteLine("       |                              |");
            Console.WriteLine("       ╚--------Press [ENTER]---------╝");

        }

        //Writes banner save and exit
        public void DrawExit()
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("╔-------------Quit-------------╗");
            Console.WriteLine("       |Are you sure [y/n]?           |");
            Console.WriteLine("       |                              |");
            Console.WriteLine("       ╚--------Press [ENTER]---------╝");

        }
    }
}


