﻿using System;
namespace scoreboardApp
{
    public class ScoreboardScreen
    {
        //Character and line position
        private int xcoord;
        private int ycoord;

        public ScoreboardScreen(int x, int y)
        {
            xcoord = x;
            ycoord = y;
        }

        public void Draw()
        {
            Console.SetCursorPosition(xcoord, ycoord);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("             Volleyball Scoreboard             ");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("–––––––––––––––––––––––––––––––––––––––––––––––");
            Console.WriteLine("                      |                        ");
            Console.WriteLine("       ╔---╗          |           ╔---╗        ");
            Console.WriteLine("       |   |          |           |   |        ");
            Console.WriteLine("       |   |          |           |   |        ");
            Console.WriteLine("       |   |    Sets  |  Sets     |   |        ");
            Console.WriteLine("       ╚---╝          |           ╚---╝        ");
            Console.WriteLine("                      |                        ");
            Console.WriteLine("  Options:            |  Options:              ");
            Console.WriteLine("    >Add Point[W]     |    >Add Point[I]       ");
            Console.WriteLine("    >Detract Point[S] |    >Detract Point[K]   ");
            Console.WriteLine("    >Add Set[D]       |    >Add Set[L]         ");
            Console.WriteLine("    >Detract Set[A]   |    >Detract Set[J]     ");
            Console.WriteLine("    >Change Name[E]   |    >Change Name[O]     ");
            Console.WriteLine("                      |                        ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("          >Reset names and goals [R]           ");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("                                               ");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("           [Escape]: Save and Exit             ");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("                                               ");
        }
    }
}



// https://www.lettercount.com/